const repo = require("./staff.repository");

class StaffService {
  async create(data) {
    return await repo.create(data);
  }

  async getAll() {
    return await repo.findAll();
  }

  async getById(id) {
    return await repo.findById(id);
  }

  async update(id, data) {
    return await repo.update(id, data);
  }

  async delete(id) {
    return await repo.delete(id);
  }
}

module.exports = new StaffService();