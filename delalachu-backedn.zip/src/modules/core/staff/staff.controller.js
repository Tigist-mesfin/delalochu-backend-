const service = require("./staff.service");
const { createStaff, updateStaff } = require("./staff.validation");

class StaffController {
  async create(req, res, next) {
    try {
      const { error } = createStaff.validate(req.body);
      if (error) return res.status(400).json({ message: error.message });

      const staff = await service.create(req.body);
      res.status(201).json(staff);
    } catch (err) {
      next(err);
    }
  }

  async getAll(req, res, next) {
    try {
      const staff = await service.getAll();
      res.json(staff);
    } catch (err) {
      next(err);
    }
  }

  async getById(req, res, next) {
    try {
      const staff = await service.getById(req.params.id);
      res.json(staff);
    } catch (err) {
      next(err);
    }
  }

  async update(req, res, next) {
    try {
      const { error } = updateStaff.validate(req.body);
      if (error) return res.status(400).json({ message: error.message });

      await service.update(req.params.id, req.body);
      res.json({ message: "Updated successfully" });
    } catch (err) {
      next(err);
    }
  }

  async delete(req, res, next) {
    try {
      await service.delete(req.params.id);
      res.json({ message: "Deleted successfully" });
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new StaffController();