const service = require("./client.service");

const {
  createClient,
  updateClient,
} = require("./client.validation");

class ClientController {
  async create(req, res, next) {
    try {
      const { error } = createClient.validate(req.body);

      if (error) {
        return res.status(400).json({
          message: error.details[0].message,
        });
      }

      const client = await service.create(req.body);

      res.status(201).json(client);
    } catch (err) {
      next(err);
    }
  }

  async getAll(req, res, next) {
    try {
      const clients = await service.getAll();

      res.json(clients);
    } catch (err) {
      next(err);
    }
  }

  async getById(req, res, next) {
    try {
      const client = await service.getById(req.params.id);

      if (!client) {
        return res.status(404).json({
          message: "Client not found",
        });
      }

      res.json(client);
    } catch (err) {
      next(err);
    }
  }

  async update(req, res, next) {
    try {
      const { error } = updateClient.validate(req.body);

      if (error) {
        return res.status(400).json({
          message: error.details[0].message,
        });
      }

      const client = await service.update(
        req.params.id,
        req.body
      );

      res.json(client);
    } catch (err) {
      next(err);
    }
  }

  async delete(req, res, next) {
    try {
      await service.delete(req.params.id);

      res.json({
        message: "Client deleted successfully",
      });
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new ClientController();